from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from django.db.models import Q, Sum, Count
from django.http import JsonResponse
from django.utils import timezone
from datetime import date, timedelta
from decimal import Decimal, InvalidOperation
import datetime
import calendar
import json

from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import AuthenticationForm
from django.db import IntegrityError, transaction
from django.core.exceptions import ValidationError


#admin    user: superuser, pass:northside1  

#physician   user: nroc_doc, pass: nroc_doctor1  

#physician   user: psa_doc,  pass: psa_doctor1 

#physician_admin  user: nroc_admin,  pass: nroc_doc1  

#physician_admin  user: psa_admin,  pass: psa_doc1,  

#nursing          user: nursing     pass: northside1 



from .models import (
    Physician, Clinic, TimeOffRequest, CoverageAssignment, PhysicianAvailability,
    CoverageRequest, UserProfile, OnCallSchedule, ClinicSchedule, DayReassignment,
    get_holidays, get_extra_workdays, is_workday, current_fiscal_year, fiscal_year_range, fiscal_year_range, 
    current_locum_fiscal_year, locum_fiscal_year_range,
)

from .forms import (
    TimeOffRequestForm, CoverageAssignmentForm,
    PhysicianAvailabilityForm, PhysicianForm, ClinicForm, OnCallScheduleForm,
    WeeklyScheduleForm,
)

from .decorators import login_required_custom, admin_required, can_approve_required, clinic_access_required


# Maps a UserProfile.scope value to the Physician.physician_type values it covers.
SCOPE_TO_TYPE = {'nroc': ['regular'], 'psa': ['psa'], 'all': ['regular', 'psa']}


def _int_param(request, name, default):
    """Read an int query param, falling back to default on garbage input."""
    try:
        return int(request.GET.get(name, default))
    except (TypeError, ValueError):
        return default


def _scope_types(profile):
    """Physician types this login may act on. Admins cover everything."""
    if profile is None:
        return []
    if profile.is_admin:
        return ['regular', 'psa']
    return SCOPE_TO_TYPE.get(profile.scope, [])


def _can_modify_time_off(profile, req):
    """Who may edit/cancel a time-off request.

    - Full admins: any request.
    - Approvers (physician administrators): any request for a physician in their scope.
    - Everyone else: only PENDING requests for physicians in their scope.
    """
    if profile is None:
        return False
    if profile.is_admin:
        return True
    if req.physician.physician_type not in _scope_types(profile):
        return False
    if profile.can_approve_time_off:
        return True
    return req.status == 'pending'


@admin_required
def dashboard(request):
    today = date.today()
    # Vacation/CME balances run on the fiscal year (Nov 1 - Oct 31, resets Nov 1)
    year = _int_param(request, 'year', current_fiscal_year())
    fy_start, fy_end = fiscal_year_range(year)
    # Locum cost figures stay on the calendar year
    cost_year = _int_param(request, 'cost_year', current_locum_fiscal_year())

    regular_physicians = Physician.objects.filter(is_active=True, physician_type='regular')
    locum_physicians = Physician.objects.filter(is_active=True, physician_type='locum')

    todays_coverage = CoverageAssignment.objects.filter(
        date=today, no_coverage_needed=False
    ).select_related('clinic', 'covering_physician', 'covered_physician')

    out_today = TimeOffRequest.objects.filter(
        status='approved', start_date__lte=today, end_date__gte=today
    ).select_related('physician')

    upcoming = TimeOffRequest.objects.filter(
        status='approved', start_date__gte=today,
        start_date__lte=today + timedelta(days=30)
    ).select_related('physician').order_by('start_date')[:10]

    pending = TimeOffRequest.objects.filter(status='pending').select_related('physician').order_by('start_date')

    # Vacation summaries for regular physicians only
    physician_summaries = []
    for p in regular_physicians:
        physician_summaries.append({
            'physician': p,
            'days_taken': p.days_taken(year),
            'days_pending': p.days_pending(year),
            'days_remaining': p.days_remaining(year),
            'total': p.total_vacation_days,
            'cme_taken': p.cme_days_taken(year),
            'cme_pending': p.cme_days_pending(year),
            'cme_remaining': p.cme_days_remaining(year),
            'cme_total': p.total_cme_days,
        })

    # Locum cost summary for the year
    locum_summaries = []
    total_locum_cost = Decimal('0.00')
    total_locum_hours = 0
    for p in locum_physicians:
        hours = p.total_coverage_hours(cost_year)
        cost = p.total_coverage_cost(cost_year)
        total_locum_cost += cost
        total_locum_hours += hours
        locum_summaries.append({
            'physician': p,
            'hours': hours,
            'cost': cost,
        })

    is_admin = getattr(getattr(request.user, 'profile', None), 'is_admin', False)

    context = {
        'year': year,
        'fy_start': fy_start,      
        'fy_end': fy_end,         
        'cost_year': cost_year,
        'today': today,
        'regular_physicians': regular_physicians,
        'locum_physicians': locum_physicians,
        'todays_coverage': todays_coverage,
        'out_today': out_today,
        'upcoming': upcoming,
        'pending': pending,
        'physician_summaries': physician_summaries,
        'locum_summaries': locum_summaries if is_admin else [],
        'total_locum_cost': total_locum_cost if is_admin else None,
        'total_locum_hours': total_locum_hours if is_admin else None,
        'is_admin': is_admin,
    }
    return render(request, 'coverage_tracker/dashboard.html', context)


@admin_required
def physician_list(request):
    physician_type = request.GET.get('type', 'regular')
    sub_tab = request.GET.get('sub', 'list')  # 'list' or 'coverage_days' for PSA
    if physician_type == 'locum':
        # Locum cost totals run on the locum fiscal year (Oct 1 - Sep 30)
        year = _int_param(request, 'year', current_locum_fiscal_year())
    else:
        year = _int_param(request, 'year', current_fiscal_year())
    physicians = Physician.objects.filter(is_active=True, physician_type=physician_type)

    summaries = []
    for p in physicians:
        if p.is_regular:
            summaries.append({
                'physician': p,
                'days_taken': p.days_taken(year),
                'days_pending': p.days_pending(year),
                'days_remaining': p.days_remaining(year),
                'total': p.total_vacation_days,
                'clinics': p.assigned_clinics.filter(is_active=True),
                'cme_taken': p.cme_days_taken(year),
                'cme_pending': p.cme_days_pending(year),
                'cme_remaining': p.cme_days_remaining(year),
                'cme_total': p.total_cme_days,
            })
        elif p.is_psa:
            summaries.append({
                'physician': p,
                'days_taken': p.days_taken(year),
                'days_pending': p.days_pending(year),
                'days_remaining': p.days_remaining(year),
                'total': p.total_vacation_days,
                'cme_taken': p.cme_days_taken(year),
                'cme_pending': p.cme_days_pending(year),
                'cme_remaining': p.cme_days_remaining(year),
                'cme_total': p.total_cme_days,
                'clinics': p.assigned_clinics.filter(is_active=True),
                'requested_days': p.requested_coverage_days(year),
            })
        else:
            summaries.append({
                'physician': p,
                'days': p.total_coverage_days(year),
                'hours': p.total_coverage_hours(year),
                'cost': p.total_coverage_cost(year),
                'clinics': [],
            })

         

    # For PSA coverage_days sub-tab, gather per-physician coverage request data
    psa_coverage_data = []
    if physician_type == 'psa' and sub_tab == 'coverage_days':
        for s in summaries:
            requests = CoverageRequest.objects.filter(
                physician=s['physician'], requested_date__year=year
            ).order_by('requested_date')
            psa_coverage_data.append({
                'physician': s['physician'],
                'requests': requests,
                'total': requests.count(),
            })

    is_admin = getattr(getattr(request.user, 'profile', None), 'is_admin', False)

    # Physicians cannot view the locum tab at all
    if physician_type == 'locum' and not is_admin:
        from django.http import HttpResponseForbidden
        messages.error(request, 'You do not have permission to view locum physician details.')
        return redirect('physician_list')

    return render(request, 'coverage_tracker/physician_list.html', {
        'summaries': summaries,
        'year': year,
        'physician_type': physician_type,
        'sub_tab': sub_tab,
        'psa_coverage_data': psa_coverage_data,
        'is_admin': is_admin,
    })


@admin_required
def physician_detail(request, pk):
    physician = get_object_or_404(Physician, pk=pk)
    if physician.is_regular or physician.is_psa:
        year = _int_param(request, 'year', current_fiscal_year())
    else:
        # Locum cost totals run on the locum fiscal year (Oct 1 - Sep 30)
        year = _int_param(request, 'year', current_locum_fiscal_year())
    time_off_requests = TimeOffRequest.objects.filter(physician=physician).order_by('-start_date')
    coverage = CoverageAssignment.objects.filter(
        covering_physician=physician
    ).order_by('-date').select_related('clinic', 'covered_physician')
    availability = PhysicianAvailability.objects.filter(
        physician=physician, date__gte=date.today()
    ).order_by('date')[:30]

    # Cost breakdown for locums
    # Cost breakdown for locums (locum fiscal year: Oct 1 - Sep 30)
    locum_fy_start, locum_fy_end = locum_fiscal_year_range(year)
    coverage_this_year = CoverageAssignment.objects.filter(
        covering_physician=physician,
        date__gte=locum_fy_start, date__lte=locum_fy_end,
    ).select_related('clinic')
    
    is_regular_like = physician.is_regular or physician.is_psa

    context = {
        'physician': physician,
        'year': year,
        'days_taken': physician.days_taken(year) if is_regular_like else None,
        'days_remaining': physician.days_remaining(year) if is_regular_like else None,
        'days_pending': physician.days_pending(year) if is_regular_like else None,
        'cme_taken': physician.cme_days_taken(year) if is_regular_like else None,
        'cme_remaining': physician.cme_days_remaining(year) if is_regular_like else None,
        'cme_pending': physician.cme_days_pending(year) if is_regular_like else None,
        'coverage_hours': physician.total_coverage_hours(year) if physician.is_locum else None,
        'coverage_cost': physician.total_coverage_cost(year) if physician.is_locum else None,
        'assigned_clinics': physician.assigned_clinics.all() if is_regular_like else [],
        'weekly_schedule': physician.weekly_schedule_display() if is_regular_like else [],
        'has_weekly_schedule': physician.has_weekly_schedule() if is_regular_like else False,
        'time_off_requests': time_off_requests,
        'coverage': coverage[:20],
        'coverage_this_year': coverage_this_year,
        'availability': availability,
    }
    return render(request, 'coverage_tracker/physician_detail.html', context)


@admin_required
def physician_schedule(request, pk):
    """Edit an NROC/PSA physician's recurring weekly clinic grid.

    Each weekday has an AM slot and a PM slot, each of which can point at a
    different clinic (or be left unscheduled), so half-day split assignments
    like 'Monday morning at Midtown, Monday afternoon at Duluth' are supported.
    """
    physician = get_object_or_404(
        Physician, pk=pk, physician_type__in=['regular', 'psa'])
    if request.method == 'POST':
        form = WeeklyScheduleForm(request.POST, physician=physician)
        if form.is_valid():
            form.save()
            messages.success(request, f'Weekly clinic schedule updated for {physician}.')
            return redirect('physician_detail', pk=pk)
    else:
        form = WeeklyScheduleForm(physician=physician)
    return render(request, 'coverage_tracker/physician_schedule.html', {
        'physician': physician,
        'form': form,
    })


@admin_required
def add_physician(request):
    if request.method == 'POST':
        form = PhysicianForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Physician added successfully.')
            return redirect('physician_list')
    else:
        ptype = request.GET.get('type', 'regular')
        form = PhysicianForm(initial={'physician_type': ptype})
    return render(request, 'coverage_tracker/form_page.html', {
        'form': form, 'title': 'Add Physician', 'back_url': 'physician_list'
    })


@admin_required
def edit_physician(request, pk):
    physician = get_object_or_404(Physician, pk=pk)
    if request.method == 'POST':
        form = PhysicianForm(request.POST, instance=physician)
        if form.is_valid():
            form.save()
            messages.success(request, 'Physician updated.')
            return redirect('physician_detail', pk=pk)
    else:
        form = PhysicianForm(instance=physician)
    return render(request, 'coverage_tracker/form_page.html', {
        'form': form, 'title': f'Edit {physician}', 'back_url': 'physician_list'
    })

@admin_required
def delete_physician(request, pk):
    """
    Delete a physician. If the physician has historical records (time-off
    requests or coverage assignments), we soft-delete by setting is_active=False
    to preserve history. Only physicians with no records are hard-deleted.
    """
    physician = get_object_or_404(Physician, pk=pk)

    if request.method != 'POST':
        # Don't support GET-based deletion — redirect back
        return redirect('physician_detail', pk=pk)

    has_time_off = TimeOffRequest.objects.filter(physician=physician).exists()
    has_coverage = (
        CoverageAssignment.objects.filter(covering_physician=physician).exists()
        or CoverageAssignment.objects.filter(covered_physician=physician).exists()
    )

    name = str(physician)

    if has_time_off or has_coverage:
        # Soft delete — preserve history
        physician.is_active = False
        physician.save()
        messages.success(
            request,
            f'{name} has historical records and was deactivated (hidden from lists). '
            f'Use "Force delete" in the admin to permanently remove.'
        )
    else:
        physician.delete()
        messages.success(request, f'{name} was deleted.')

    return redirect('physician_list')

@login_required_custom
def time_off_list(request):
    profile = getattr(request.user, 'profile', None)
    is_admin = bool(profile and profile.is_admin)
    is_physician_admin = bool(profile and profile.is_physician_admin)
    can_approve = bool(profile and profile.can_approve_time_off)
    status = request.GET.get('status', '')
    physician_id = request.GET.get('physician', '')
    qs = TimeOffRequest.objects.select_related('physician').order_by('-start_date')

    # Full admins see everything (with optional filters); physician admins and
    # physicians see all pending + approved requests across the team.
    viewer_scope = profile.scope if profile else 'nroc'
    # 'nroc' here maps to the DB value 'regular' on Physician.physician_type.

    if is_admin:
        if status:
            qs = qs.filter(status=status)
        if physician_id:
            qs = qs.filter(physician_id=physician_id)
    else:
        qs = qs.filter(status__in=['pending', 'approved'])
        allowed_types = SCOPE_TO_TYPE.get(viewer_scope, [])
        if allowed_types:
            qs = qs.filter(physician__physician_type__in=allowed_types)
        else:
            qs = qs.none()

    physicians = Physician.objects.filter(is_active=True, physician_type__in=['regular', 'psa'])

    # Resolve the logged-in user's physician record (used to mark their own requests)
    viewer_physician = profile.physician if profile else None

    # Attach coverage info to each approved request
    enriched_requests = []
    for req in qs:
        coverage = None
        coverage_status = None
        if req.status == 'approved':
            assignments = CoverageAssignment.objects.filter(
                covered_physician=req.physician,
                date__gte=req.start_date,
                date__lte=req.end_date,
            ).select_related('covering_physician', 'clinic').order_by('date')
            covered_dates = set(a.date for a in assignments)
            all_dates_count = req.duration_days
            if assignments.exists():
                if len(covered_dates) >= all_dates_count:
                    coverage_status = 'full'
                else:
                    coverage_status = 'partial'
            else:
                coverage_status = 'none'
            # Get unique locums
            locum_names = list({a.covering_physician for a in assignments if a.covering_physician_id})
            coverage = locum_names
        enriched_requests.append({
            'req': req,
            'coverage': coverage,
            'coverage_status': coverage_status,
            'is_own': viewer_physician is not None and req.physician_id == viewer_physician.pk,
        })

    return render(request, 'coverage_tracker/time_off_list.html', {
        'enriched_requests': enriched_requests,
        'physicians': physicians,
        'status_filter': status,
        'physician_filter': physician_id,
        'is_admin': is_admin,
        'is_physician_admin': is_physician_admin,
        'can_approve': can_approve,
    })

def _on_call_weekends_for_physicians(physician_qs):
    """Build a JSON-serializable dict of upcoming on-call weekends per physician.

    Used by the time-off form's client-side warning: if a vacation ends on
    the day before, or starts on the day after, one of the physician's
    on-call shifts (Mon–Sun), the form pops a confirm() dialog before submitting.

    Returns {physician_id (str): [monday_iso, ...]}. Includes the current
    in-progress week (Monday up to six days back) plus everything onward —
    past shifts can't conflict with a new
    """
    today = timezone.now().date()
    entries = OnCallSchedule.objects.filter(
        physician__in=physician_qs,
        weekend_start_date__gte=today - timedelta(days=6),
    ).values_list('physician_id', 'weekend_start_date')


    result = {}
    for pid, mon in entries:
        result.setdefault(str(pid), []).append(mon.isoformat())
   

def _oncall_conflicts_for_request(physician, start_date, end_date):
    """Detect on-call duty that collides with a proposed time-off window.

    Flags an on-call day that lands on:
      * the day BEFORE the time off begins,
      * the day AFTER the time off ends, or
      * any day DURING the time off (start_date .. end_date inclusive).

    Each OnCallSchedule row covers a full week — Monday
    (`weekend_start_date`) through the following Sunday — so every entry
    contributes seven candidate on-call days. A shift conflicts when any
    of those days falls inside the window [start_date - 1, end_date + 1].

    Returns a list of human-readable warning strings (empty when there is
    no conflict), suitable for showing in a click-through warning box.
    """
    if not (physician and start_date and end_date):
        return []

    window_start = start_date - timedelta(days=1)
    window_end = end_date + timedelta(days=1)

    # Filter generously by Saturday date (one extra day on the low side so a
    # Saturday sitting just before the window can still contribute its
    # Sunday), then classify each candidate day precisely below.
    entries = OnCallSchedule.objects.filter(
        physician=physician,
        weekend_start_date__gte=window_start - timedelta(days=6),
        weekend_start_date__lte=window_end,
    ).order_by('weekend_start_date')

    warnings = []
    for entry in entries:
        for offset in range(7):  # Monday .. Sunday
            on_call_day = entry.monday + timedelta(days=offset)
            if start_date <= on_call_day <= end_date:
                warnings.append(
                    f"{physician} is on call ({entry.get_group_display()}) on "
                    f"{on_call_day:%a, %b %d, %Y} — during the requested time off "
                    f"(on-call week of {entry.weekend_label})."
                )
    return warnings


@login_required_custom
def add_time_off(request):
    profile = getattr(request.user, 'profile', None)
    is_admin = bool(profile and profile.is_admin)
    viewer_scope = profile.scope if profile else 'nroc'

    # Which physician types may this login submit for?
    allowed_types = SCOPE_TO_TYPE.get(viewer_scope, ['regular', 'psa']) if not is_admin else ['regular', 'psa']

    def restrict_queryset(form):
        form.fields['physician'].queryset = Physician.objects.filter(
            is_active=True, physician_type__in=allowed_types,
        ).order_by('last_name', 'first_name')

    if request.method == 'POST':
        form = TimeOffRequestForm(request.POST)
        # Status is always pending for new requests — remove from form
        form.fields.pop('status', None)
        restrict_queryset(form)
        if form.is_valid():
            req = form.save(commit=False)
            # Never let a non-admin submit for a physician outside their scope
            if not is_admin and req.physician.physician_type not in allowed_types:
                messages.error(request, 'You can only submit time off for physicians in your group.')
                return redirect('time_off_list')
            
            acknowledged = request.POST.get('acknowledge_oncall') == '1'
            oncall_warnings = _oncall_conflicts_for_request(
                req.physician, req.start_date, req.end_date
            )

            if oncall_warnings and not acknowledged:
                return render(request, 'coverage_tracker/form_page.html', {
                    'form': form, 'title': 'Request Time Off', 'back_url': 'time_off_list',
                    'on_call_weekends_by_physician': _on_call_weekends_for_physicians(
                        form.fields['physician'].queryset
                    ),
                    'oncall_warnings': oncall_warnings,
                })
            
            req.status = 'pending'
            req.save()
            messages.success(request, 'Time off request submitted.')
            return redirect('time_off_list')
    else:
        physician_id = request.GET.get('physician')
        initial = {'physician': physician_id} if physician_id and is_admin else {}
        form = TimeOffRequestForm(initial=initial)

    # Status is always pending for new requests — hide on render
    form.fields.pop('status', None)
    restrict_queryset(form)

    return render(request, 'coverage_tracker/form_page.html', {
        'form': form, 'title': 'Request Time Off', 'back_url': 'time_off_list',
        'on_call_weekends_by_physician': _on_call_weekends_for_physicians(
            form.fields['physician'].queryset
        ),
    })


def _remove_coverage_for_request(req):
    """Delete all CoverageAssignments linked to this time-off request's physician and date range."""
    deleted_qs = CoverageAssignment.objects.filter(
        covered_physician=req.physician,
        date__gte=req.start_date,
        date__lte=req.end_date,
    )
    count = deleted_qs.count()
    deleted_qs.delete()
    return count


@login_required_custom
def edit_time_off(request, pk):
    req = get_object_or_404(TimeOffRequest, pk=pk)
    profile = getattr(request.user, 'profile', None)

    # Permission: admins anything; approvers anything in scope;
    # everyone else only pending requests in their scope.
    if not _can_modify_time_off(profile, req):
        messages.error(request, 'You do not have permission to edit that request.')
        return redirect('time_off_list')

    can_set_status = bool(profile and profile.can_approve_time_off)
    old_status = req.status

    def prepare(form):
        """Only approvers may change status; everyone else gets the field removed.
        Non-admins may only pick physicians inside their own scope (mirrors
        add_time_off), so a request can't be reassigned across groups."""
        if not can_set_status:
            form.fields.pop('status', None)
        if not (profile and profile.is_admin):
            form.fields['physician'].queryset = form.fields['physician'].queryset.filter(
                physician_type__in=_scope_types(profile)
            )
        return form

    if request.method == 'POST':
        form = prepare(TimeOffRequestForm(request.POST, instance=req))
        if form.is_valid():
            # On-call conflict check (skip for requests being cancelled/denied,
            # where an on-call collision no longer matters). Show a warning the
            # user can click through by re-submitting with acknowledgement.
            candidate = form.save(commit=False)
            acknowledged = request.POST.get('acknowledge_oncall') == '1'
            oncall_warnings = []
            if candidate.status not in ('cancelled', 'denied'):
                oncall_warnings = _oncall_conflicts_for_request(
                    candidate.physician, candidate.start_date, candidate.end_date
                )
            if oncall_warnings and not acknowledged:
                return render(request, 'coverage_tracker/form_page.html', {
                    'form': form, 'title': 'Edit Time Off Request', 'back_url': 'time_off_list',
                    'on_call_weekends_by_physician': _on_call_weekends_for_physicians(
                        form.fields['physician'].queryset
                    ),
                    'oncall_warnings': oncall_warnings,
                })
            updated = form.save()
            # If status changed TO cancelled or denied, remove coverage assignments
            if updated.status in ('cancelled', 'denied') and old_status not in ('cancelled', 'denied'):
                removed = _remove_coverage_for_request(updated)
                if removed:
                    messages.warning(
                        request,
                        f'Request {updated.status}. {removed} locum coverage assignment{"s" if removed != 1 else ""} removed.'
                    )
                else:
                    messages.success(request, f'Request {updated.status}.')
            else:
                messages.success(request, 'Request updated.')
            return redirect('time_off_list')
    else:
        form = prepare(TimeOffRequestForm(instance=req))
    return render(request, 'coverage_tracker/form_page.html', {
        'form': form, 'title': 'Edit Time Off Request', 'back_url': 'time_off_list',
        'on_call_weekends_by_physician': _on_call_weekends_for_physicians(
            form.fields['physician'].queryset
        ),
    })


@login_required_custom
def cancel_time_off(request, pk):
    """One-click cancellation: removes coverage assignments and sets status to cancelled.

    POST-only (state-changing). The request row is KEPT with status='cancelled'
    so history and the audit trail survive — it is never deleted here.
    """
    req = get_object_or_404(TimeOffRequest, pk=pk)

    if request.method != 'POST':
        return redirect('time_off_list')

    profile = getattr(request.user, 'profile', None)
    if not _can_modify_time_off(profile, req):
        messages.error(request, 'You do not have permission to cancel that request.')
        return redirect('time_off_list')

    if req.status == 'cancelled':
        messages.info(request, 'Request is already cancelled.')
        return redirect('time_off_list')

    removed = _remove_coverage_for_request(req)
    req.status = 'cancelled'
    req.save()

    if removed:
        messages.warning(
            request,
            f'Time off for {req.physician} cancelled. '
            f'{removed} locum coverage assignment{"s" if removed != 1 else ""} removed.'
        )
    else:
        messages.success(request, f'Time off for {req.physician} cancelled.')
    return redirect('time_off_list')


@can_approve_required
def approve_time_off(request, pk):
    if request.method != 'POST':
        return redirect('time_off_list')
    req = get_object_or_404(TimeOffRequest, pk=pk)
    profile = getattr(request.user, 'profile', None)
    if not (profile and (profile.is_admin or req.physician.physician_type in _scope_types(profile))):
        messages.error(request, 'You can only approve requests for physicians in your group.')
        return redirect('time_off_list')
    req.status = 'approved'
    req.save()
    messages.success(request, f'Approved time off for {req.physician}.')
    return redirect('time_off_list')


@can_approve_required
def deny_time_off(request, pk):
    if request.method != 'POST':
        return redirect('time_off_list')
    req = get_object_or_404(TimeOffRequest, pk=pk)
    profile = getattr(request.user, 'profile', None)
    if not (profile and (profile.is_admin or req.physician.physician_type in _scope_types(profile))):
        messages.error(request, 'You can only deny requests for physicians in your group.')
        return redirect('time_off_list')
    req.status = 'denied'
    req.save()
    messages.warning(request, f'Denied time off for {req.physician}.')
    return redirect('time_off_list')


def _staffing_base():
    """Prefetch the data needed to compute daily clinic staffing.

    Returns (clinics, slots, schedule_managed_ids): active clinics with their
    legacy physician affiliations, all weekly-schedule slots for active
    physicians, and the ids of every physician managed by the weekly grid.
    """
    clinics = list(
        Clinic.objects.filter(is_active=True).prefetch_related('regular_physicians')
    )
    slots = list(
        ClinicSchedule.objects.filter(physician__is_active=True)
        .select_related('physician', 'clinic')
    )
    schedule_managed_ids = set(
        ClinicSchedule.objects.values_list('physician_id', flat=True)
    )
    return clinics, slots, schedule_managed_ids


def _clinic_sessions_for_date(view_date, clinics, slots, schedule_managed_ids,
                              reassignments):
    """Effective staffing for one date, merging three layers:

    weekly schedule -> legacy full-week affiliation (physicians without a
    weekly grid) -> one-day reassignments on top.

    Returns (clinic_sessions, reassigned_slots) where clinic_sessions is
    {clinic_id: {physician: set of 'am'/'pm' sessions here}} and
    reassigned_slots is {(physician_id, session, clinic_id)} for badging.
    """
    weekday = view_date.weekday()
    effective = {}  # physician -> {'am': set of clinic_ids, 'pm': ...}

    def _sessions_for(p):
        return effective.setdefault(p, {'am': set(), 'pm': set()})

    for slot in slots:
        if slot.day_of_week == weekday:
            _sessions_for(slot.physician)[slot.session].add(slot.clinic_id)
    for clinic in clinics:
        for p in clinic.regular_physicians.all():
            if p.id not in schedule_managed_ids and p.is_active:
                sess = _sessions_for(p)
                sess['am'].add(clinic.id)
                sess['pm'].add(clinic.id)

    reassigned_slots = set()
    for r in reassignments:
        sess = _sessions_for(r.physician)
        override_sessions = ['am', 'pm'] if r.session == 'full' else [r.session]
        for s in override_sessions:
            sess[s] = {r.clinic_id}
            reassigned_slots.add((r.physician.id, s, r.clinic_id))

    clinic_sessions = {}
    for p, sess in effective.items():
        for s in ('am', 'pm'):
            for cid in sess[s]:
                clinic_sessions.setdefault(cid, {}).setdefault(p, set()).add(s)
    return clinic_sessions, reassigned_slots


def _session_label(sessions):
    return ('Full day' if sessions >= {'am', 'pm'}
            else ('AM' if 'am' in sessions else 'PM'))


@clinic_access_required
def clinic_list(request):
    selected_date = request.GET.get('date', str(date.today()))
    try:
        view_date = datetime.datetime.strptime(selected_date, '%Y-%m-%d').date()
    except ValueError:
        view_date = date.today()

    clinics = Clinic.objects.filter(is_active=True).prefetch_related('regular_physicians')

    # ── Who works where today? ────────────────────────────────────────────
    # Weekly schedule -> legacy affiliation fallback -> day reassignments.
    # (Shared with the monthly calendar; see _clinic_sessions_for_date.)
    clinics, slots, schedule_managed_ids = _staffing_base()
    reassignments = DayReassignment.objects.filter(
        date=view_date, physician__is_active=True,
    ).select_related('physician', 'clinic')
    clinic_sessions, reassigned_slots = _clinic_sessions_for_date(
        view_date, clinics, slots, schedule_managed_ids, reassignments)

    # Map each out physician to their approved time-off request so the
    # template can deep-link straight to that request's assignment page.
    out_reqs = {
        r.physician_id: r.pk
        for r in TimeOffRequest.objects.filter(
            status='approved', start_date__lte=view_date, end_date__gte=view_date
        )
    }
    
    out_ids = set(out_reqs)
    # Physicians who already have locum coverage recorded for this date —
    # they should no longer get an "assign" form, but other out physicians
    # at the same clinic still should.
    covered_today_ids = set(
        CoverageAssignment.objects.filter(
            date=view_date, no_coverage_needed=False,
            covered_physician__isnull=False,
        ).values_list('covered_physician_id', flat=True)
    )


    clinic_data = []
    for clinic in clinics:
        assignments = CoverageAssignment.objects.filter(
            clinic=clinic, date=view_date, no_coverage_needed=False       # ← added
        ).select_related('covering_physician', 'covered_physician')
        no_cov_physician_ids = set(                                       # ← NEW
        CoverageAssignment.objects.filter(
            date=view_date, no_coverage_needed=True
        ).values_list('covered_physician_id', flat=True)
        )
        # Staff for this clinic today (half-day aware; weekly schedule,
        # legacy affiliation, and day reassignments were merged above).
        staff_today = []
        for p, sessions in clinic_sessions.get(clinic.id, {}).items():
            staff_today.append({
                'physician': p,
                'label': 'Full day' if sessions >= {'am', 'pm'}
                         else ('AM' if 'am' in sessions else 'PM'),
                'is_out': p.id in out_ids and p.id not in no_cov_physician_ids,
                'reassigned': any(
                    (p.id, s, clinic.id) in reassigned_slots for s in sessions
                ),
            })
        staff_today.sort(key=lambda s: (s['physician'].last_name,
                                        s['physician'].first_name))
        regular_out = [s['physician'] for s in staff_today if s['is_out']]
        clinic_data.append({
            'clinic': clinic,
            'assignments': assignments,
            'staff_today': staff_today,
            'regular_out': regular_out,
            # One link per out physician (NROC or PSA), straight to the
            # assignment page for their time-off request.
            'out_links': [
                {'physician': p, 'req_pk': out_reqs[p.id]}
                for p in regular_out if p.id not in covered_today_ids
            ],
        })

    available_locums = Physician.objects.filter(
        is_active=True, physician_type='locum'
    ).exclude(
        coverage_assignments__date=view_date
    )

    return render(request, 'coverage_tracker/clinic_list.html', {
        'clinic_data': clinic_data,
        'view_date': view_date,
        'available_locums': available_locums,
        'reassignments': reassignments,
        'reassignable_physicians': Physician.objects.filter(
            is_active=True, physician_type__in=['regular', 'psa']
        ).order_by('last_name', 'first_name'),
        'all_clinics': clinics,
        'session_choices': DayReassignment.SESSION_CHOICES,
    })

@admin_required
def reassign_physician_day(request):
    """Manually reassign an NROC/PSA physician to a different clinic for one
    day (or one half day), straight from the clinics page."""
    if request.method != 'POST':
        return redirect('clinic_list')

    date_str = request.POST.get('date', '')
    try:
        target_date = datetime.datetime.strptime(date_str, '%Y-%m-%d').date()
    except ValueError:
        messages.error(request, 'Invalid date.')
        return redirect('clinic_list')

    back = f'/clinics/?date={target_date}'
    try:
        physician = Physician.objects.get(
            pk=request.POST.get('physician'), is_active=True,
            physician_type__in=['regular', 'psa'])
        clinic = Clinic.objects.get(pk=request.POST.get('clinic'), is_active=True)
    except (Physician.DoesNotExist, Clinic.DoesNotExist, ValueError, TypeError):
        messages.error(request, 'Pick a physician and a clinic.')
        return redirect(back)

    session = request.POST.get('session', 'full')
    if session not in dict(DayReassignment.SESSION_CHOICES):
        session = 'full'

    reassignment = DayReassignment(
        physician=physician, clinic=clinic, date=target_date,
        session=session, note=request.POST.get('note', '').strip(),
    )
    try:
        reassignment.full_clean()
        reassignment.save()
    except ValidationError as e:
        messages.error(request, ' '.join(
            m for msgs in e.message_dict.values() for m in msgs))
        return redirect(back)

    messages.success(
        request,
        f'{physician} reassigned to {clinic} on {target_date} '
        f'({reassignment.get_session_display()}).')
    return redirect(back)


@admin_required
def delete_reassignment(request, pk):
    if request.method != 'POST':
        return redirect('clinic_list')
    reassignment = get_object_or_404(DayReassignment, pk=pk)
    back = f'/clinics/?date={reassignment.date}'
    messages.success(
        request,
        f'Removed reassignment: {reassignment.physician} → '
        f'{reassignment.clinic} on {reassignment.date}.')
    reassignment.delete()
    return redirect(back)


@login_required_custom
def calendar_view(request):
    """Monthly calendar: who is scheduled at which clinic each day, and who
    is off. Clicking a day shows the full per-clinic summary for that day.

    Uses the same layering as the clinics page: weekly schedule -> legacy
    clinic affiliation fallback -> one-day reassignments, plus approved
    time off for the 'off' list.
    """
    today = date.today()
    year = _int_param(request, 'year', today.year)
    month = _int_param(request, 'month', today.month)
    if not (1 <= month <= 12):
        month = today.month
    if not (2000 <= year <= 2100):
        year = today.year

    first_of_month = date(year, month, 1)
    prev_month = (first_of_month - timedelta(days=1)).replace(day=1)
    next_month = (first_of_month + timedelta(days=32)).replace(day=1)

    # Calendar grid (weeks start on Sunday), including adjacent-month days.
    cal = calendar.Calendar(firstweekday=6)
    weeks = cal.monthdatescalendar(year, month)
    span_start, span_end = weeks[0][0], weeks[-1][-1]

    # ── Bulk-fetch everything for the whole grid ──────────────────────────
    clinics = list(Clinic.objects.filter(is_active=True))

    schedule_rows = list(ClinicSchedule.objects.filter(
        physician__is_active=True).select_related('physician', 'clinic'))
    schedule_managed_ids = {r.physician_id for r in schedule_rows}
    slots_by_weekday = {}
    for r in schedule_rows:
        slots_by_weekday.setdefault(r.day_of_week, []).append(r)

    legacy_pairs = []  # (physician, clinic) for physicians without a weekly grid
    for c in Clinic.objects.filter(is_active=True).prefetch_related('regular_physicians'):
        for p in c.regular_physicians.all():
            if p.is_active and p.id not in schedule_managed_ids:
                legacy_pairs.append((p, c))

    reassigns_by_date = {}
    for r in DayReassignment.objects.filter(
            date__gte=span_start, date__lte=span_end,
            physician__is_active=True).select_related('physician', 'clinic'):
        reassigns_by_date.setdefault(r.date, []).append(r)

    off_by_date = {}
    for req in TimeOffRequest.objects.filter(
            status='approved', start_date__lte=span_end, end_date__gte=span_start,
            physician__is_active=True,
            physician__physician_type__in=['regular', 'psa'],
            ).select_related('physician'):
        d = max(req.start_date, span_start)
        stop = min(req.end_date, span_end)
        while d <= stop:
            off_by_date.setdefault(d, set()).add(req.physician)
            d += timedelta(days=1)

    # Locum coverage: date -> {covered_physician_id: covering locum}
    cover_by_date = {}
    for ca in CoverageAssignment.objects.filter(
            date__gte=span_start, date__lte=span_end,
            covering_physician__isnull=False,
            covered_physician__isnull=False,
            ).select_related('covering_physician', 'covered_physician'):
        cover_by_date.setdefault(ca.date, {})[ca.covered_physician_id] = ca.covering_physician

    holidays, extra = set(), set()
    for y in {span_start.year, span_end.year}:
        holidays |= set(get_holidays(y))
        extra |= get_extra_workdays(y)

    # ── Per-day staffing (same layering as the clinics page) ──────────────
    def staffing_for(day):
        effective = {}   # physician -> {'am': set(clinic_ids), 'pm': ...}
        reassigned_slots = set()

        def sess_for(p):
            return effective.setdefault(p, {'am': set(), 'pm': set()})

        for slot in slots_by_weekday.get(day.weekday(), []):
            sess_for(slot.physician)[slot.session].add(slot.clinic_id)
        for p, c in legacy_pairs:
            s = sess_for(p)
            s['am'].add(c.id)
            s['pm'].add(c.id)
        for r in reassigns_by_date.get(day, []):
            s = sess_for(r.physician)
            for ss in (['am', 'pm'] if r.session == 'full' else [r.session]):
                s[ss] = {r.clinic_id}
                reassigned_slots.add((r.physician.id, ss, r.clinic_id))

        by_clinic = {}   # clinic_id -> {physician: set(sessions)}
        for p, s in effective.items():
            for ss in ('am', 'pm'):
                for cid in s[ss]:
                    by_clinic.setdefault(cid, {}).setdefault(p, set()).add(ss)
        return by_clinic, reassigned_slots

    weeks_data = []
    day_summaries = {}   # date iso -> JSON-safe summary for the click panel
    for week in weeks:
        row = []
        for day in week:
            workday = is_workday(day, holidays, extra)
            cell = {
                'date': day,
                'in_month': day.month == month,
                'is_workday': workday,
                'is_today': day == today,
                'clinics': [],
                'off': [],
            }
            summary = {
                'label': f"{day.strftime('%A, %B')} {day.day}, {day.year}",
                'workday': workday,
                'clinics': [],
                'off': [],
            }
            if workday:
                by_clinic, reassigned_slots = staffing_for(day)
                off_today = off_by_date.get(day, set())
                covers = cover_by_date.get(day, {})
                for c in clinics:
                    people = by_clinic.get(c.id)
                    if not people:
                        continue
                    staff = []
                    for p, sessions in sorted(
                            people.items(),
                            key=lambda kv: (kv[0].last_name, kv[0].first_name)):
                        staff.append({
                            'name': str(p),
                            'initials': f"{p.first_name[:1]}{p.last_name[:1]}".upper(),
                            'label': ('Full day' if sessions >= {'am', 'pm'}
                                      else ('AM' if 'am' in sessions else 'PM')),
                            'out': p in off_today,
                            'covered_by': (str(covers[p.id])
                                           if p in off_today and p.id in covers
                                           else None),
                            'psa': p.is_psa,
                            'reassigned': any(
                                (p.id, ss, c.id) in reassigned_slots
                                for ss in sessions),
                        })
                    cell['clinics'].append({'clinic': c, 'staff': staff})
                    summary['clinics'].append(
                        {'name': c.name, 'staff': staff})
                off_sorted = sorted(
                    off_today, key=lambda p: (p.last_name, p.first_name))
                cell['off'] = off_sorted
                summary['off'] = [str(p) for p in off_sorted]
                summary['off_detail'] = [
                    {'name': str(p), 'psa': p.is_psa,
                     'covered_by': str(covers[p.id]) if p.id in covers else None}
                    for p in off_sorted]
            day_summaries[day.isoformat()] = summary
            row.append(cell)
        weeks_data.append(row)

    return render(request, 'coverage_tracker/calendar.html', {
        'weeks': weeks_data,
        'month_label': f"{calendar.month_name[month]} {year}",
        'prev_month': prev_month,
        'next_month': next_month,
        'today': today,
        'day_summaries': day_summaries,
        'weekday_headers': ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
    })


@admin_required
def assign_day_coverage(request):
    """Assign a locum to cover one physician for a single day, straight from
    the clinics page. Works for both NROC and PSA physicians (records are
    created directly, like the time-off assignment flow)."""
    if request.method != 'POST':
        return redirect('clinic_list')

    date_str = request.POST.get('date', '')
    try:
        target_date = datetime.datetime.strptime(date_str, '%Y-%m-%d').date()
    except ValueError:
        messages.error(request, 'Invalid date.')
        return redirect('clinic_list')

    back = f'/clinics/?date={target_date}'

    try:
        clinic = Clinic.objects.get(pk=request.POST.get('clinic'), is_active=True)
        physician = Physician.objects.get(
            pk=request.POST.get('physician'), is_active=True,
            physician_type__in=['regular', 'psa'])
        locum = Physician.objects.get(
            pk=request.POST.get('locum'), is_active=True, physician_type='locum')
    except (Clinic.DoesNotExist, Physician.DoesNotExist, ValueError, TypeError):
        messages.error(request, 'Could not assign coverage — invalid selection.')
        return redirect(back)

    try:
        hours = Decimal(request.POST.get('hours', '').strip() or '8.00')
        if hours < 0:
            hours = Decimal('8.00')
    except InvalidOperation:
        hours = Decimal('8.00')

    try:
        with transaction.atomic():
            existing = CoverageAssignment.objects.filter(
                covered_physician=physician, date=target_date).first()
            if existing:
                existing.covering_physician = locum
                existing.clinic = clinic
                existing.hours = hours
                existing.no_coverage_needed = False
                existing.no_coverage_reason = ''
                existing.save()
            else:
                CoverageAssignment.objects.create(
                    clinic=clinic,
                    covering_physician=locum,
                    covered_physician=physician,
                    date=target_date,
                    hours=hours,
                    notes=f'Single-day assignment from clinics page ({target_date})',
                )
    except IntegrityError:
        messages.error(
            request,
            f'{locum} already has an assignment at {clinic.name} on '
            f'{target_date:%b %d}. Pick a different locum.')
        return redirect(back)

    messages.success(
        request,
        f'{locum} assigned to cover {physician} at {clinic.name} on '
        f'{target_date:%b %d, %Y}.')
    return redirect(back)


@admin_required
def add_clinic(request):
    if request.method == 'POST':
        form = ClinicForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Clinic added.')
            return redirect('clinic_list')
    else:
        form = ClinicForm()
    return render(request, 'coverage_tracker/form_page.html', {
        'form': form, 'title': 'Add Clinic', 'back_url': 'clinic_list'
    })


@admin_required
def edit_clinic(request, pk):
    clinic = get_object_or_404(Clinic, pk=pk)
    if request.method == 'POST':
        form = ClinicForm(request.POST, instance=clinic)
        if form.is_valid():
            form.save()
            messages.success(request, 'Clinic updated.')
            return redirect('clinic_list')
    else:
        form = ClinicForm(instance=clinic)
    return render(request, 'coverage_tracker/form_page.html', {
        'form': form, 'title': f'Edit {clinic}', 'back_url': 'clinic_list'
    })


@admin_required
def add_coverage(request):
    if request.method == 'POST':
        form = CoverageAssignmentForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Coverage assignment added.')
            return redirect('clinic_list')
    else:
        date_str = request.GET.get('date', str(date.today()))
        form = CoverageAssignmentForm(initial={'date': date_str})
    return render(request, 'coverage_tracker/form_page.html', {
        'form': form, 'title': 'Assign Locum Coverage', 'back_url': 'clinic_list'
    })


@admin_required
def delete_coverage(request, pk):
    assignment = get_object_or_404(CoverageAssignment, pk=pk)
    date_str = str(assignment.date)
    if request.method != 'POST':
        return redirect(f'/clinics/?date={date_str}')
    assignment.delete()
    messages.success(request, 'Coverage assignment removed.')
    return redirect(f'/clinics/?date={date_str}')


@admin_required
def locum_reports(request):
    """Monthly timesheet-style report for one locum: date, hours, facility,
    and supervising (covered) physician per shift, mirroring the Northside
    physician time sheet. Each shift defaults to 8 hours unless the coverage
    record has explicit hours.
    """
    today = date.today()
    locums = Physician.objects.filter(
        is_active=True, physician_type='locum'
    ).order_by('last_name', 'first_name')

    # Selected locum (default: first) and month ('YYYY-MM', default: current).
    locum = None
    locum_pk = request.GET.get('locum')
    if locum_pk:
        locum = locums.filter(pk=locum_pk).first()
    if locum is None:
        locum = locums.first()

    month_str = request.GET.get('month', '')
    try:
        report_year, report_month = (int(x) for x in month_str.split('-'))
        date(report_year, report_month, 1)  # validates
    except (ValueError, TypeError):
        report_year, report_month = today.year, today.month

    rows, total_hours = [], Decimal('0')
    if locum:
        assignments = CoverageAssignment.objects.filter(
            covering_physician=locum, no_coverage_needed=False,
            date__year=report_year, date__month=report_month,
        ).select_related('clinic', 'covered_physician').order_by('date')
        for a in assignments:
            hours = a.hours if a.hours else Decimal('8')
            total_hours += hours
            rows.append({
                'date': a.date,
                'hours': hours,
                'facility': a.clinic.name,
                'supervisor': str(a.covered_physician) if a.covered_physician else '—',
            })

    # Pad with blank rows so the printed sheet looks like the paper form.
    blank_rows = range(max(0, 15 - len(rows)))

    return render(request, 'coverage_tracker/locum_reports.html', {
        'locums': locums,
        'locum': locum,
        'rows': rows,
        'blank_rows': blank_rows,
        'total_hours': total_hours,
        'month_value': f'{report_year}-{report_month:02d}',
        'month_label': f'{calendar.month_name[report_month]}, {report_year}',
        'facilities': sorted({r['facility'] for r in rows}),
    })


@admin_required
def locum_costs(request):
    
    # Locum costs run on the locum fiscal year: Oct 1 - Sep 30, labeled by the
    # year it ends (FY2026 = Oct 1 2025 - Sep 30 2026). Totals reset every 10/1.
    year = _int_param(request, 'year', current_locum_fiscal_year())
    month = _int_param(request, 'month', 0)  # 0 = no month filter
    fy_start, fy_end = locum_fiscal_year_range(year)

    assignments = CoverageAssignment.objects.filter(
        date__gte=fy_start, date__lte=fy_end, no_coverage_needed=False
    ).select_related('covering_physician', 'clinic', 'covered_physician')

    if month:
        assignments = assignments.filter(date__month=month)

    assignments = assignments.order_by('date', 'clinic')
    #for a in list(assignments):
        #print(a)
        #a.delete()

    # Per-locum rollup
    locums = Physician.objects.filter(is_active=True, physician_type='locum')
    locum_data = []
    grand_total = Decimal('0.00')
    grand_hours = Decimal('0.00')

    for p in locums:
        yr_assignments = [a for a in assignments if a.covering_physician_id == p.id]
        hours = sum(((a.hours or Decimal('0.00')) for a in yr_assignments), Decimal('0.00'))
        cost = sum(a.cost for a in yr_assignments)
        grand_total += cost
        grand_hours += hours
        
        locum_data.append({
            'physician': p,
            'hours': hours,
            'cost': cost,
            'standard_rate': p.hourly_rate,
        })

    # Monthly breakdown
    # Monthly breakdown (fiscal year order: Oct ... Sep)
    monthly_totals = {}
    for a in CoverageAssignment.objects.filter(
        date__gte=fy_start, date__lte=fy_end
    ).select_related('covering_physician'):
        if a.no_coverage_needed or a.covering_physician is None:          # ← guard
            continue
        m = a.date.month
        if m not in monthly_totals:
            monthly_totals[m] = {'hours': 0, 'cost': Decimal('0.00')}
        monthly_totals[m]['hours'] += (a.hours or Decimal('0.00'))
        monthly_totals[m]['cost'] += a.cost

    months = []
    month_names = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
    fiscal_month_order = [10, 11, 12, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    for i in fiscal_month_order:
        d = monthly_totals.get(i, {'hours': Decimal('0.00'), 'cost': Decimal('0.00')})
        months.append({'num': i, 'name': month_names[i-1], **d})
    #num_assigned = 0
    num_assigned = sum(1 for s in locum_data if s['hours'] > 0)
    #print([1 for s in locum_data if s['days'] > 0])
    if grand_hours > 0:
        avg_hourly_rate = (grand_total / grand_hours).quantize(Decimal('0.01'))
    else:
        avg_hourly_rate = Decimal('0.00')
    


    context = {
        'year': year,
        'month_filter': month,
        'assignments': assignments,
        'locum_data': locum_data,
        'months': months,
        'grand_total': grand_total,
        'grand_hours': grand_hours,
        'avg_hourly_rate': avg_hourly_rate,
        'assigned_count': num_assigned,
        'years': [2023, 2024, 2025, 2026, 2027],
    }
    return render(request, 'coverage_tracker/locum_costs.html', context)


@admin_required
def availability_view(request):
    selected_date = request.GET.get('date', str(date.today()))
    try:
        view_date = datetime.datetime.strptime(selected_date, '%Y-%m-%d').date()
    except ValueError:
        view_date = date.today()

    week_start = view_date - timedelta(days=view_date.weekday())
    all_days = [week_start + timedelta(days=i) for i in range(21)]

    holidays = set(get_holidays(week_start.year))
    if all_days[-1].year != week_start.year:
        holidays |= set(get_holidays(all_days[-1].year))

    extra = get_extra_workdays(week_start.year)
    if all_days[-1].year != week_start.year:
        extra |= get_extra_workdays(all_days[-1].year)
   

    calendar_days = [d for d in all_days if is_workday(d, holidays, extra) or (d in holidays and d.weekday() < 5)]


    # All active physicians (not just locums)
    all_physicians = Physician.objects.filter(is_active=True, physician_type = 'locum').order_by('last_name', 'first_name')

    time_off = TimeOffRequest.objects.filter(
        status='approved',
        start_date__lte=calendar_days[-1],
        end_date__gte=calendar_days[0]
    )

    off_set = set()
    for req in time_off:
        d = req.start_date
        while d <= req.end_date:
            off_set.add((req.physician_id, d))
            d += timedelta(days=1)

    assigned_set = set()
    for a in CoverageAssignment.objects.filter(
        date__gte=calendar_days[0], date__lte=calendar_days[-1]
    ):
        assigned_set.add((a.covering_physician_id, a.date))

    # Load manual availability overrides for all physicians
    avail_map = {}
    for av in PhysicianAvailability.objects.filter(
        date__gte=calendar_days[0], date__lte=calendar_days[-1]
    ):
        avail_map[(av.physician_id, av.date)] = 'available' if av.is_available else 'unavailable'

    grid = []
    for p in all_physicians:
        row = []
        for d in calendar_days:
            if d in holidays:
                row.append('holiday')
            elif (p.id, d) in assigned_set:
                row.append('assigned')
            elif (p.id, d) in off_set:
                row.append('unavailable')
            elif (p.id, d) in avail_map:
                row.append(avail_map[(p.id, d)])
            else:
                row.append('available')
        grid.append({'physician': p, 'days': row})

    return render(request, 'coverage_tracker/availability.html', {
        'grid': grid,
        'calendar_days': calendar_days,
        'view_date': view_date,
        'today': date.today(),
        'holiday_set': holidays,
    })


@admin_required
def update_availability_note(request):
    """AJAX endpoint: save a free-text availability note for a physician."""
    if request.method != 'POST':
        return JsonResponse({'error': 'POST required.'}, status=405)

    try:
        data = json.loads(request.body)
    except (json.JSONDecodeError, UnicodeDecodeError):
        return JsonResponse({'error': 'Invalid JSON body.'}, status=400)

    try:
        physician = Physician.objects.get(pk=data.get('physician_id'), is_active=True)
    except (Physician.DoesNotExist, ValueError, TypeError):
        return JsonResponse({'error': 'Physician not found.'}, status=404)

    note = (data.get('note') or '').strip()
    if len(note) > 500:
        return JsonResponse({'error': 'Note is too long (500 characters max).'}, status=400)

    physician.availability_notes = note
    physician.save(update_fields=['availability_notes'])
    return JsonResponse({'ok': True, 'note': note})


@admin_required
def update_availability(request):
    """AJAX endpoint: set a physician's availability for a specific date."""
    if request.method != 'POST':
        return JsonResponse({'error': 'POST required.'}, status=405)

    try:
        data = json.loads(request.body)
    except (json.JSONDecodeError, UnicodeDecodeError):
        return JsonResponse({'error': 'Invalid JSON body.'}, status=400)

    status = data.get('status')  # 'available', 'assigned', 'unavailable'
    if status == 'assigned':
        # Cannot assign via this endpoint; return error
        return JsonResponse({'error': 'Use the coverage assignment form to assign coverage.'}, status=400)
    if status not in ('available', 'unavailable'):
        return JsonResponse({'error': 'Invalid status.'}, status=400)

    try:
        physician = Physician.objects.get(pk=data.get('physician_id'), is_active=True)
    except (Physician.DoesNotExist, ValueError, TypeError):
        return JsonResponse({'error': 'Physician not found.'}, status=404)

    try:
        target_date = datetime.datetime.strptime(data.get('date') or '', '%Y-%m-%d').date()
    except ValueError:
        return JsonResponse({'error': 'Invalid date.'}, status=400)

    removed = CoverageAssignment.objects.filter(
        covering_physician=physician,
        date=target_date,
    ).delete()[0]

    PhysicianAvailability.objects.update_or_create(
        physician=physician,
        date=target_date,
        defaults={'is_available': (status == 'available')},
    )

    return JsonResponse({
        'ok': True,
        'status': status,
        'assignments_removed': removed,
    })


@admin_required
def approved_time_off_coverage(request):
    """
    Shows all approved time-off requests with per-day locum coverage.
    """
    today = date.today()
    year = _int_param(request, 'year', today.year)

    approved_requests = TimeOffRequest.objects.filter(
        status='approved',
        start_date__year=year,
    ).select_related('physician').order_by('-start_date')

    enriched = []
    for req in approved_requests:
        existing_coverage = {
            a.date: a
            for a in CoverageAssignment.objects.filter(
                covered_physician=req.physician,
                date__gte=req.start_date,
                date__lte=req.end_date,
            ).select_related('covering_physician', 'clinic')
        }

        all_dates = req.workdays()

        day_coverage = []
        uncovered_dates = []
        for day in all_dates:
            assignment = existing_coverage.get(day)
            day_coverage.append({'date': day, 'assignment': assignment})
            if not assignment:
                uncovered_dates.append(day)

        has_full_coverage = len(uncovered_dates) == 0
        has_partial_coverage = bool(existing_coverage) and not has_full_coverage

        enriched.append({
            'request': req,
            'day_coverage': day_coverage,
            'coverage': list(existing_coverage.values()),
            'uncovered_dates': uncovered_dates,
            'has_full_coverage': has_full_coverage,
            'has_partial_coverage': has_partial_coverage,
            'duration': req.duration_days,
        })

    years = list(range(today.year - 1, today.year + 3))

    return render(request, 'coverage_tracker/approved_time_off_coverage.html', {
        'enriched': enriched,
        'year': year,
        'years': years,
        'today': today,
    })


def _build_day_locum_data(all_locums, day, current_covered_physician=None):
    """Helper: for a given date, return each locum with conflict info.

    A "conflict" means the locum is already covering someone ELSE on this day.
    The locum who's already assigned to `current_covered_physician` is NOT a
    conflict — they are the currently-selected assignment and must stay in
    the dropdown so the template can mark them as selected.
    """
    result = []
    for locum in all_locums:
        # Find any assignments for this locum on this day
        conflicting_qs = CoverageAssignment.objects.filter(
            covering_physician=locum, date=day
        ).exclude(covered_physician=None)

        # Ignore the assignment that covers the physician we're editing right now
        if current_covered_physician is not None:
            conflicting_qs = conflicting_qs.exclude(covered_physician=current_covered_physician)

        conflict = conflicting_qs.exists()

        # Always include the locum — show the conflict tag if they're
        # genuinely double-booked on some OTHER physician's coverage.
        result.append({
            'physician': locum,
            'has_conflict': conflict,
        })
    return result


@admin_required
def assign_locum_to_time_off(request, pk):
    """
    Per-day locum assignment for a time-off request.
    Shows each uncovered day with its own locum + clinic selector.
    """
    req = get_object_or_404(TimeOffRequest, pk=pk, status='approved')

    # Build full date list (business days, holiday- and cross-year-aware)
    all_dates = req.workdays()

    # Existing assignments keyed by date
    existing_assignments = {
        a.date: a
        for a in CoverageAssignment.objects.filter(
            covered_physician=req.physician,
            date__gte=req.start_date,
            date__lte=req.end_date,
        ).select_related('covering_physician', 'clinic')
    }

    if request.method == 'POST':
        clinics = {c.pk: c for c in Clinic.objects.filter(is_active=True)}
        locums = {p.pk: p for p in Physician.objects.filter(is_active=True, physician_type='locum')}
        saved = 0
        errors = []

        for day in all_dates:
            date_key = day.strftime('%Y-%m-%d')
            mode = request.POST.get(f'mode_{date_key}', 'locum')    
            locum_id = request.POST.get(f'locum_{date_key}')
            clinic_id = request.POST.get(f'clinic_{date_key}')
            clear = request.POST.get(f'clear_{date_key}')
            hours_raw = request.POST.get(f'hours_{date_key}', '').strip()
            no_cov_reason = request.POST.get(                              # ← NEW
                f'no_coverage_reason_{date_key}', ''
            ).strip()

            existing = existing_assignments.get(day)

            if clear:
                if existing:
                    existing.delete()
                continue


            if mode == 'none':
                if not no_cov_reason:
                    errors.append(
                        f'{day.strftime("%b %d")}: A reason is required when marking '
                        f'a day as "no coverage needed".'
                    )
                    continue
                if not clinic_id:
                    errors.append(
                        f'{day.strftime("%b %d")}: A clinic must still be assigned '
                        f'to the day off, even when no coverage is needed.'
                    )
                    continue
                try:
                    clinic_id_int = int(clinic_id)
                except (ValueError, TypeError):
                    continue
                clinic = clinics.get(clinic_id_int)
                if not clinic:
                    continue

                if existing:
                    existing.no_coverage_needed = True
                    existing.no_coverage_reason = no_cov_reason
                    existing.covering_physician = None
                    existing.clinic = clinic
                    existing.hours = None
                    existing.hourly_rate_override = None
                    existing.save()
                else:
                    CoverageAssignment.objects.create(
                        clinic=clinic,
                        covering_physician=None,
                        covered_physician=req.physician,
                        date=day,
                        hours=None,
                        no_coverage_needed=True,
                        no_coverage_reason=no_cov_reason,
                        notes=f'No coverage needed for time off: {req.start_date} – {req.end_date}',
                    )
                saved += 1
                continue

            



            if locum_id and not clinic_id:
                errors.append(f'{day.strftime("%b %d")}: A locum is selected but no clinic is assigned.')
                continue
            if clinic_id and not locum_id:
                errors.append(f'{day.strftime("%b %d")}: A clinic is selected but no locum is assigned.')
                continue
            if not locum_id and not clinic_id:
                continue  # Both blank — intentionally skipped

            
            try:
                locum_id = int(locum_id)
                clinic_id = int(clinic_id)
            except (ValueError, TypeError):
                continue

            try:
                hours_value = Decimal(hours_raw) if hours_raw else Decimal('8.00')
                if hours_value < 0:
                    hours_value = Decimal('8.00')
            except (InvalidOperation, TypeError):
                hours_value = Decimal('8.00')


            locum = locums.get(locum_id)
            clinic = clinics.get(clinic_id)
            if not locum or not clinic:
                continue

            if existing:
                # Update existing assignment
                existing.covering_physician = locum
                existing.clinic = clinic
                existing.hours = hours_value
                existing.no_coverage_needed = False                     # ← NEW
                existing.no_coverage_reason = '' 
                existing.save()
                saved += 1
            else:
                CoverageAssignment.objects.create(
                    clinic=clinic,
                    covering_physician=locum,
                    covered_physician=req.physician,
                    date=day,
                    hours=hours_value,
                    notes=f'Assigned for time off: {req.start_date} – {req.end_date}',
                )
                saved += 1
        if errors:
            for err in errors:
                messages.error(request, err)
            # ... rebuild day_rows ...
            return redirect('assign_locum_to_time_off', pk=req.pk)


        messages.success(request, f'Coverage updated: {saved} day(s) saved for {req.physician}.')
        return redirect('approved_time_off_coverage')

    # GET — build per-day rows
    all_locums = Physician.objects.filter(is_active=True, physician_type='locum')
    clinics = Clinic.objects.filter(is_active=True)
    physician_clinics = list(req.physician.assigned_clinics.filter(is_active=True))
    default_clinic = physician_clinics[0] if physician_clinics else None



    

    day_rows = []
    for day in all_dates:
        existing = existing_assignments.get(day)
        locum_options = _build_day_locum_data(all_locums, day,current_covered_physician=req.physician)
        day_rows.append({
            'date': day,
            'existing': existing,
            'locum_options': locum_options,
            'is_covered': existing is not None,
        })

    return render(request, 'coverage_tracker/assign_locum.html', {
        'req': req,
        'day_rows': day_rows,
        'clinics': clinics,
        'physician_clinics': physician_clinics,
        'default_clinic': default_clinic,
        'all_dates': all_dates,
    })


@admin_required
def edit_coverage_for_time_off(request, pk):
    """
    Edit existing per-day coverage for an approved time-off request.
    Same form as assign but pre-populated with existing assignments.
    """
    # Reuse the same view — just redirect to assign page
    return redirect('assign_locum_to_time_off', pk=pk)


@admin_required
def delete_time_off_coverage_day(request, assignment_pk):
    """Delete a single day's coverage assignment, redirect back to coverage page."""
    if request.method != 'POST':
        return redirect('approved_time_off_coverage')
    assignment = get_object_or_404(CoverageAssignment, pk=assignment_pk)
    covered = assignment.covered_physician
    assignment.delete()
    if covered:
        messages.success(request, f'Coverage removed for {covered} on {assignment.date}.')
    else:
        messages.success(request, 'Coverage assignment removed.')
    return redirect('approved_time_off_coverage')


@admin_required
def mark_availability(request):
    if request.method == 'POST':
        form = PhysicianAvailabilityForm(request.POST)
        if form.is_valid():
            PhysicianAvailability.objects.update_or_create(
                physician=form.cleaned_data['physician'],
                date=form.cleaned_data['date'],
                defaults={
                    'is_available': form.cleaned_data['is_available'],
                    'notes': form.cleaned_data.get('notes', '')
                }
            )
            messages.success(request, 'Availability updated.')
            return redirect('availability')
    else:
        form = PhysicianAvailabilityForm()
    return render(request, 'coverage_tracker/form_page.html', {
        'form': form, 'title': 'Mark Locum Availability', 'back_url': 'availability'
    })


@login_required_custom
def psa_coverage_request_view(request):
    year = _int_param(request, 'year', date.today().year)
    physicians = Physician.objects.filter(is_active=True, physician_type='psa').order_by('last_name', 'first_name')
    data = []
    for p in physicians:
        # Days where a locum actually covered this PSA physician
        assignments = CoverageAssignment.objects.filter(
            covered_physician=p, date__year=year, no_coverage_needed=False,
        ).select_related('covering_physician', 'clinic').order_by('date')



        total_hours = sum(((a.hours or Decimal('0.00')) for a in assignments), Decimal('0.00'))
        total_cost = sum((a.cost for a in assignments), Decimal('0.00'))

        data.append({
            'physician': p,
            'assignments': assignments,
            'total': len(assignments),
            'total_hours': total_hours,
            'total_cost': total_cost,
        })
    # Sort: physicians with the most locum-covered days first
    data.sort(key=lambda r: r['total'], reverse=True)

    return render(request, 'coverage_tracker/psa_coverage_requests.html', {
        'data': data,
        'year': year,
    })


@login_required_custom
def add_coverage_request(request):
    from django import forms as dj_forms

    profile = getattr(request.user, 'profile', None)

    # Only logins whose scope covers PSA physicians (or admins) may record
    # PSA coverage requests.
    if 'psa' not in _scope_types(profile):
        messages.error(request, 'You do not have permission to record PSA coverage requests.')
        return redirect('time_off_list')

    # Only approvers (admins / physician administrators) may set a status;
    # everyone else's submissions are always recorded as 'pending'.
    can_set_status = bool(profile and profile.can_approve_time_off)

    class CoverageRequestForm(dj_forms.Form):
        physician = dj_forms.ModelChoiceField(
            queryset=Physician.objects.filter(is_active=True, physician_type='psa'),
            label='PSA Physician'
        )
        requested_date = dj_forms.DateField(widget=dj_forms.DateInput(attrs={'type': 'date'}))
        status = dj_forms.ChoiceField(choices=CoverageRequest.STATUS_CHOICES, initial='pending')
        notes = dj_forms.CharField(required=False, widget=dj_forms.Textarea(attrs={'rows': 2}))

    if request.method == 'POST':
        form = CoverageRequestForm(request.POST)
        if not can_set_status:
            form.fields.pop('status', None)
        if form.is_valid():
            status = form.cleaned_data['status'] if can_set_status else 'pending'
            CoverageRequest.objects.update_or_create(
                physician=form.cleaned_data['physician'],
                requested_date=form.cleaned_data['requested_date'],
                defaults={
                    'status': status,
                    'notes': form.cleaned_data.get('notes', ''),
                }
            )
            messages.success(request, 'Coverage request recorded.')
            return redirect('psa_coverage_request')
    else:
        form = CoverageRequestForm()
        if not can_set_status:
            form.fields.pop('status', None)
    return render(request, 'coverage_tracker/form_page.html', {
        'form': form,
        'title': 'Add PSA Coverage Request',
        'back_url': 'psa_coverage_request',
    })


@login_required_custom
def delete_coverage_request(request, pk):
    req = get_object_or_404(CoverageRequest, pk=pk)
    if request.method != 'POST':
        return redirect('psa_coverage_request')
    profile = getattr(request.user, 'profile', None)
    if not (profile and profile.can_approve_time_off and 'psa' in _scope_types(profile)):
        messages.error(request, 'You do not have permission to delete coverage requests.')
        return redirect('psa_coverage_request')
    req.delete()
    messages.success(request, 'Coverage request deleted.')
    return redirect('psa_coverage_request')


# ─── Auth Views ──────────────────────────────────────────────────────────────

def _post_login_landing(user):
    """Where to send a user after login (or when they hit '/').
    Admins get the dashboard; everyone else goes to the time-off list.
    """
    profile = getattr(user, 'profile', None)
    if profile and profile.is_admin:
        return 'dashboard'
    
    if profile and profile.is_nursing:
        return 'clinic_list'

    return 'time_off_list'

def login_view(request):
    if request.user.is_authenticated:
        return redirect(_post_login_landing(request.user))
    form = AuthenticationForm(request, data=request.POST or None)
    if request.method == 'POST' and form.is_valid():
        user = form.get_user()
        login(request, user)
        # Ensure profile exists
        UserProfile.objects.get_or_create(user=user)
        next_url = request.GET.get('next') or request.POST.get('next')
        # Honor "next" only if it's set and not the root/dashboard
        # (otherwise non-admins would still get bounced to a forbidden page)
        if next_url and next_url not in ('/', '/dashboard/', '/dashboard'):
            return redirect(next_url)
        return redirect(_post_login_landing(user))
    return render(request, 'coverage_tracker/login.html', {'form': form, 'next': request.GET.get('next', '')})


def logout_view(request):
    logout(request)
    return redirect('/login/')


# ─── User Management (Admin only) ────────────────────────────────────────────

@admin_required
def user_management(request):
    from django.contrib.auth.models import User as DjangoUser
    users = DjangoUser.objects.select_related('profile').order_by('last_name', 'first_name')
    # Ensure profile exists for all users
    for u in users:
        UserProfile.objects.get_or_create(user=u)
    users = DjangoUser.objects.select_related('profile__physician').order_by('last_name', 'first_name')
    return render(request, 'coverage_tracker/user_management.html', {'users': users})


@admin_required
def add_user(request):
    from django.contrib.auth.models import User as DjangoUser
    from django import forms as dj_forms

    class AddUserForm(dj_forms.Form):
        
        username     = dj_forms.CharField(max_length=150, widget=dj_forms.TextInput(attrs={'class': 'form-control'}))
        password     = dj_forms.CharField(widget=dj_forms.PasswordInput(attrs={'class': 'form-control'}), min_length=6)
        role         = dj_forms.ChoiceField(choices=[('physician', 'Physician'),('physician_admin', 'Physician Administrator'), ('admin', 'Administrator'), ('nursing', 'Nursing')],
                                             widget=dj_forms.Select(attrs={'class': 'form-control'}))
        
        scope        = dj_forms.ChoiceField(
            label='Group',
            choices=[
                ('nroc', 'NROC Physicians'),
                ('psa', 'PSA Physicians'),
                ('all', 'Both NROC and PSA'),
            ],
            initial='nroc',
            widget=dj_forms.Select(attrs={'class': 'form-control'}),
        )

        

    if request.method == 'POST':
        form = AddUserForm(request.POST)
        if form.is_valid():
            cd = form.cleaned_data
            if DjangoUser.objects.filter(username=cd['username']).exists():
                form.add_error('username', 'Username already taken.')
            else:
                user = DjangoUser.objects.create_user(
                    username=cd['username'],
                    
                    password=cd['password'],
                    
                )
                UserProfile.objects.update_or_create(
                user=user,
                defaults={
                    'role': form.cleaned_data['role'],
                    'scope': form.cleaned_data.get('scope', 'nroc'),
                    'physician': None,
                },
            )
                messages.success(request, f"Account created for {user.get_full_name() or user.username}.")
                return redirect('user_management')
    else:
        form = AddUserForm()

    return render(request, 'coverage_tracker/form_page.html', {
        'form': form,
        'title': 'Add User Account',
        'back_url': 'user_management',
    })


@admin_required
def edit_user(request, pk):
    from django.contrib.auth.models import User as DjangoUser
    from django import forms as dj_forms

    user = get_object_or_404(DjangoUser, pk=pk)
    profile, _ = UserProfile.objects.get_or_create(user=user)

    class EditUserForm(dj_forms.Form):
        
       
        role        = dj_forms.ChoiceField(choices=[('physician', 'Physician'), ('physician_admin', 'Physician Administrator'), ('admin', 'Administrator'), ('nursing', 'Nursing')],
                                            widget=dj_forms.Select(attrs={'class': 'form-control'}))
        scope   = dj_forms.ChoiceField(
            label='Group',
            choices=[
                ('nroc', 'NROC Physicians'),
                ('psa', 'PSA Physicians'),
                ('all', 'Both NROC and PSA'),
            ],
            initial='nroc',
            widget=dj_forms.Select(attrs={'class': 'form-control'}),
        )
       
        new_password = dj_forms.CharField(
            required=False, min_length=6,
            widget=dj_forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Leave blank to keep current'}),
            help_text='Only fill this in to change the password.'
        )
        is_active   = dj_forms.BooleanField(required=False, initial=True)

    if request.method == 'POST':
        form = EditUserForm(request.POST)
        if form.is_valid():
            cd = form.cleaned_data
            
            user.is_active  = cd.get('is_active', True)
            if cd.get('new_password'):
                user.set_password(cd['new_password'])
            user.save()
            profile.role      = cd['role']
            profile.scope     = cd.get('scope', 'nroc')
            profile.physician = None
            profile.save()
            messages.success(request, f"Account updated for {user.get_full_name() or user.username}.")
            return redirect('user_management')
    else:
        form = EditUserForm(initial={
            'first_name': user.first_name,
            'last_name':  user.last_name,
            'email':      user.email,
            'role':       profile.role,
            'scope':      profile.scope,
            
            'is_active':  user.is_active,
        })

    return render(request, 'coverage_tracker/form_page.html', {
        'form': form,
        'title': f'Edit Account — {user.get_full_name() or user.username}',
        'back_url': 'user_management',
    })


@admin_required
def delete_user(request, pk):
    from django.contrib.auth.models import User as DjangoUser
    user = get_object_or_404(DjangoUser, pk=pk)
    if request.method != 'POST':
        # Never delete on GET (link prefetchers, typed URLs, etc.)
        return redirect('user_management')
    if user == request.user:
        messages.error(request, "You cannot delete your own account.")
        return redirect('user_management')
    name = user.get_full_name() or user.username
    user.delete()
    messages.success(request, f"Account for {name} deleted.")
    return redirect('user_management')


# ─── Change Password (all logged-in users) ───────────────────────────────────

@admin_required  
def change_password(request):
    from django import forms as dj_forms
    from django.contrib.auth import update_session_auth_hash

    class ChangePasswordForm(dj_forms.Form):
        current_password = dj_forms.CharField(
            widget=dj_forms.PasswordInput(attrs={'class': 'form-control'}),
            label='Current Password'
        )
        new_password = dj_forms.CharField(
            widget=dj_forms.PasswordInput(attrs={'class': 'form-control'}),
            label='New Password', min_length=6
        )
        confirm_password = dj_forms.CharField(
            widget=dj_forms.PasswordInput(attrs={'class': 'form-control'}),
            label='Confirm New Password'
        )

        def clean(self):
            cleaned = super().clean()
            if cleaned.get('new_password') != cleaned.get('confirm_password'):
                raise dj_forms.ValidationError('New passwords do not match.')
            return cleaned

    if request.method == 'POST':
        form = ChangePasswordForm(request.POST)
        if form.is_valid():
            if not request.user.check_password(form.cleaned_data['current_password']):
                form.add_error('current_password', 'Current password is incorrect.')
            else:
                request.user.set_password(form.cleaned_data['new_password'])
                request.user.save()
                update_session_auth_hash(request, request.user)
                messages.success(request, 'Password updated successfully.')
                return redirect('dashboard')
    else:
        form = ChangePasswordForm()

    return render(request, 'coverage_tracker/form_page.html', {
        'form': form,
        'title': 'Change Password',
        'back_url': 'dashboard',
    })

# ─── On-Call Schedule Views ─────────────────────────────────────────────────
#
# On-call is weekend-only: each entry covers Saturday + Sunday as a single
# assignment, keyed by the Saturday date.
#
# Viewing is open to every authenticated user.
# Create / edit / delete is admin-only.

def _weekend_starts_in_range(start_date, end_date):
    monday = start_date - timedelta(days=start_date.weekday())
    while monday <= end_date:
        yield monday
        monday += timedelta(days=7)


@login_required_custom
def on_call_schedule(request):
    """Display the week on-call schedule.

    Query params:
      - group:      'nroc' | 'psa' | 'all'   (default 'all')
      - start_date: ISO date (default today)
      - end_date:   ISO date (default start_date + 90 days, ~13 weekends)

    Every authenticated user can view this page.
    """
    group_filter = request.GET.get('group', 'all')
    if group_filter not in ('nroc', 'psa', 'all'):
        group_filter = 'all'

    today = date.today()

    try:
        start_date = datetime.datetime.strptime(
            request.GET.get('start_date', ''), '%Y-%m-%d'
        ).date()
    except (ValueError, TypeError):
        start_date = today
    try:
        end_date = datetime.datetime.strptime(
            request.GET.get('end_date', ''), '%Y-%m-%d'
        ).date()
    except (ValueError, TypeError):
        end_date = start_date + timedelta(days=90)

    if end_date < start_date:
        end_date = start_date + timedelta(days=90)

    # Pull every entry whose Saturday is inside the requested window
    entries_qs = OnCallSchedule.objects.filter(
        weekend_start_date__gte=start_date - timedelta(days=6),
        weekend_start_date__lte=end_date,
    ).select_related('physician').order_by('weekend_start_date', 'group')

    if group_filter in ('nroc', 'psa'):
        entries_qs = entries_qs.filter(group=group_filter)

    by_weekend = {}
    for mon in _weekend_starts_in_range(start_date, end_date):
        by_weekend[mon] = {
            'monday': mon,
            'sunday': mon + timedelta(days=6),
            'nroc': [],
            'psa': [],
        }

    for entry in entries_qs:
        mon = entry.weekend_start_date
        if mon in by_weekend:
            by_weekend[mon][entry.group].append(entry)

    weekend_rows = [by_weekend[m] for m in sorted(by_weekend.keys())]

    current_shift_monday = today - timedelta(days=today.weekday())

    

    is_admin = getattr(getattr(request.user, 'profile', None), 'is_admin', False)

    return render(request, 'coverage_tracker/on_call_schedule.html', {
        'weekend_rows': weekend_rows,
        'group_filter': group_filter,
        'start_date': start_date,
        'end_date': end_date,
        'today': today,
        'current_shift_monday': current_shift_monday,
        'is_admin': is_admin,
        'show_nroc': group_filter in ('nroc', 'all'),
        'show_psa': group_filter in ('psa', 'all'),
    })


# AFTER
@admin_required
def add_on_call(request):
    """Admin: add a new week on-call entry."""
    initial_group = request.GET.get('group')  # 'nroc' / 'psa' optional preselect
    initial_weekend = request.GET.get('weekend_start_date')  # 'YYYY-MM-DD' optional

    if request.method == 'POST':
        form = OnCallScheduleForm(request.POST)
        if form.is_valid():
            entry = form.save(commit=False)
            try:
                entry.save()
                messages.success(
                    request,
                    f"Week on-call added: {entry.physician} — {entry.weekend_label}."
                )
                return redirect('on_call_schedule')
            except IntegrityError:
                # Race: another admin saved a conflicting row between our
                # form.is_valid() check and this save. Surface the same
                # friendly message we'd have shown if we'd caught it earlier.
                form.add_error(
                    None,
                    "Another admin just saved a conflicting entry. "
                    "Please reload the schedule and try again."
                )
        # Falls through to re-render with form errors visible
    else:
        form = OnCallScheduleForm(group=initial_group, weekend_start_date=initial_weekend)

    return render(request, 'coverage_tracker/on_call_form.html', {
        'form': form,
        'title': 'Add Week On-Call',
        'back_url': 'on_call_schedule',
    })


@admin_required
def edit_on_call(request, pk):
    """Admin: edit an existing week on-call entry."""
    entry = get_object_or_404(OnCallSchedule, pk=pk)

    if request.method == 'POST':
        form = OnCallScheduleForm(request.POST, instance=entry)
        if form.is_valid():
            updated = form.save(commit=False)
            try:
                updated.save()
                messages.success(request, 'Week on-call updated.')
                return redirect('on_call_schedule')
            except IntegrityError:
                form.add_error(
                    None,
                    "Another admin just saved a conflicting entry. "
                    "Please reload the schedule and try again."
                )
    else:
        form = OnCallScheduleForm(instance=entry)

    return render(request, 'coverage_tracker/on_call_form.html', {
        'form': form,
        'title': 'Edit Week On-Call',
        'back_url': 'on_call_schedule',
        'entry': entry,
    })

@admin_required
def delete_on_call(request, pk):
    """Admin: delete an on-call entry."""
    entry = get_object_or_404(OnCallSchedule, pk=pk)
    if request.method == 'POST':
        entry.delete()
        messages.success(request, 'Week on-call removed.')
        return redirect('on_call_schedule')
    return render(request, 'coverage_tracker/on_call_confirm_delete.html', {
        'entry': entry,
    })