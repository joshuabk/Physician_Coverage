from django.db import models
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from django.utils import timezone
from datetime import date
import datetime
import calendar
from decimal import Decimal


def get_holidays(year):
    holidays = []
    
    # Fixed holidays
    holidays.append(date(year, 1, 1))   # New Year's Day
    holidays.append(date(year, 7, 4))   # Independence Day
    holidays.append(date(year, 12, 25)) # Christmas Day
    may_cal = calendar.monthcalendar(year, 5)
    last_monday_may = [week[0] for week in may_cal if week[0] != 0][-1]
    holidays.append(date(year, 5, last_monday_may))
    
    # Labor Day: First Monday in September
    sep_cal = calendar.monthcalendar(year, 9)
    first_monday_sep = next(week[0] for week in sep_cal if week[0] != 0)
    holidays.append(date(year, 9, first_monday_sep))
    
    # Thanksgiving: 4th Thursday in November
    nov_cal = calendar.monthcalendar(year, 11)
    thursdays = [week[3] for week in nov_cal if week[3] != 0]  # Thursday index = 3
    fourth_thursday = thursdays[3]
    holidays.append(date(year, 11, fourth_thursday))
    
    return sorted(holidays)


def get_extra_workdays(year):
    """Weekend days that should be treated as workdays (schedulable)."""
    extra = set()
    # Sunday before Thanksgiving
    nov_cal = calendar.monthcalendar(year, 11)
    thursdays = [week[3] for week in nov_cal if week[3] != 0]
    fourth_thursday = thursdays[3]
    thanksgiving = date(year, 11, fourth_thursday)
    sunday_before = thanksgiving - datetime.timedelta(days=4)  # Thu - 4 = Sun
    extra.add(sunday_before)
    return extra


def is_workday(d, holidays=None, extra_workdays=None):
    """Return True if d is a schedulable workday (Mon-Fri, or an extra workday, minus holidays)."""
    if holidays and d in holidays:
        return False
    if extra_workdays and d in extra_workdays:
        return True
    return d.weekday() < 5

# ─── Fiscal year (vacation & CME pools reset every January 1) ────────────────

FISCAL_YEAR_START_MONTH = 1  # January


def fiscal_year_for(d):
    """Pools run on the calendar year: FY N is Jan 1 – Dec 31 of year N."""
    return d.year


def fiscal_year_range(year):
    """Inclusive (start, end) dates of fiscal year `year`."""
    return (date(year, 1, 1), date(year, 12, 31))


def current_fiscal_year():
    return fiscal_year_for(timezone.now().date())

# ─── Locum-cost fiscal year (cost totals reset every January 1) ──────────────

LOCUM_FY_START_MONTH = 1  # January


def locum_fiscal_year_for(d):
    """Cost totals run on the calendar year: FY N is Jan 1 – Dec 31 of year N."""
    return d.year


def locum_fiscal_year_range(year):
    """Inclusive (start, end) dates of locum-cost fiscal year `year`."""
    return (date(year, 1, 1), date(year, 12, 31))


def current_locum_fiscal_year():
    return locum_fiscal_year_for(timezone.now().date())

class Physician(models.Model):
    PHYSICIAN_TYPE_CHOICES = [
        ('regular', 'NROC Physician'),
        ('locum', 'Locum / Covering Physician'),
        ('psa', 'PSA Physician'),
    ]

    user = models.OneToOneField(User, on_delete=models.CASCADE, null=True, blank=True)
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    
    physician_type = models.CharField(max_length=10, choices=PHYSICIAN_TYPE_CHOICES, default='regular')
    total_vacation_days = models.PositiveIntegerField(
        default=20,
        help_text="Annual vacation day allocation (for NROC physicians)"
    )

    total_cme_days = models.PositiveIntegerField(
        default=5,
        help_text="Annual CME / education day allocation"
    )

    daily_rate = models.DecimalField(
        max_digits=10, decimal_places=2, null=True, blank=True,
        help_text="Legacy / standard daily rate (kept for reference — hourly rate is used for pay)"
    )
    hourly_rate = models.DecimalField(
        max_digits=10, decimal_places=2, null=True, blank=True,
        help_text="Hourly rate for locum physicians. Daily pay = hourly rate × hours worked."
    )
    agency = models.CharField(
        max_length=200, blank=True,
        help_text="Staffing agency name (for locum physicians)"
    )
    availability_notes = models.TextField(
        blank=True,
        help_text="Free-text availability note shown on the availability page (e.g. 'Out until October — maternity leave')."
    )
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ['physician_type', 'last_name', 'first_name']

    def __str__(self):
        return f"Dr. {self.first_name} {self.last_name}"

    @property
    def is_locum(self):
        return self.physician_type == 'locum'

    @property
    def is_regular(self):
        return self.physician_type == 'regular'

    @property
    def is_psa(self):
        return self.physician_type == 'psa'

    def _pool_days(self, request_types, status, fiscal_year):
        """Business days of matching requests charged to a fiscal year.

        Pools reset every November 1: a request belongs to the fiscal year
        containing its START date (FY N = Nov 1 of N-1 through Oct 31 of N).
        """
        if fiscal_year is None:
            fiscal_year = current_fiscal_year()
        fy_start, fy_end = fiscal_year_range(fiscal_year)
        total = 0
        for req in TimeOffRequest.objects.filter(physician=self, status=status,
                                                 request_type__in=request_types,
                                                 start_date__gte=fy_start,
                                                 start_date__lte=fy_end):
            total += req.duration_days
        return total

    def days_taken(self, year=None):
        return self._pool_days(['vacation', 'sick'], 'approved', year)

    def days_remaining(self, year=None):
        return self.total_vacation_days - self.days_taken(year)

    def days_pending(self, year=None):
        return self._pool_days(['vacation', 'sick'], 'pending', year)

    def cme_days_taken(self, year=None):
        return self._pool_days(['conference'], 'approved', year)

    def cme_days_pending(self, year=None):
        return self._pool_days(['conference'], 'pending', year)

    def cme_days_remaining(self, year=None):
        return self.total_cme_days - self.cme_days_taken(year)

    def total_coverage_days(self, year=None):
        if year is None:
            year = timezone.now().year
        return CoverageAssignment.objects.filter(covering_physician=self, date__year=year).count()
    
    def total_coverage_days(self, year=None):
        """Coverage days worked in a locum fiscal year (Oct 1 – Sep 30)."""
        if year is None:
            year = current_locum_fiscal_year()
        fy_start, fy_end = locum_fiscal_year_range(year)
        return CoverageAssignment.objects.filter(
            covering_physician=self, date__gte=fy_start, date__lte=fy_end
        ).count()
    
    def total_coverage_hours(self, year=None):
        """Coverage hours worked in a locum fiscal year (Oct 1 – Sep 30)."""
        if year is None:
            year = current_locum_fiscal_year()
        fy_start, fy_end = locum_fiscal_year_range(year)
        from django.db.models import Sum
        result = CoverageAssignment.objects.filter(
            covering_physician=self, date__gte=fy_start, date__lte=fy_end
        ).aggregate(total=Sum('hours'))
        return result['total'] or Decimal('0.00')

    def total_coverage_cost(self, year=None):
        """Coverage cost accrued in a locum fiscal year (Oct 1 – Sep 30).

        Totals reset every October 1 (fiscal year ends 9/30).
        """
        if year is None:
            year = current_locum_fiscal_year()
        fy_start, fy_end = locum_fiscal_year_range(year)
        assignments = CoverageAssignment.objects.filter(
            covering_physician=self, date__gte=fy_start, date__lte=fy_end
        )
        total = Decimal('0.00')
        for a in assignments:
            rate = a.hourly_rate_override if a.hourly_rate_override is not None else self.hourly_rate
            if rate is None or a.hours is None:
                continue
            total += (rate * a.hours)
        return total.quantize(Decimal('0.01'))

    def requested_coverage_days(self, year=None):
        if year is None:
            year = timezone.now().year
        return CoverageRequest.objects.filter(physician=self, requested_date__year=year).count()


    def has_weekly_schedule(self):
        """True once this physician's clinics are managed by the weekly grid."""
        return self.clinic_schedule.exists()

    def weekly_schedule_display(self):
        """Template-friendly grid: [{'day': 'Monday', 'am': row|None, 'pm': row|None}, ...]"""
        grid = {day: {'am': None, 'pm': None} for day, _ in ClinicSchedule.DAY_CHOICES}
        for row in self.clinic_schedule.select_related('clinic'):
            grid[row.day_of_week][row.session] = row
        return [
            {'day': name, 'am': grid[day]['am'], 'pm': grid[day]['pm']}
            for day, name in ClinicSchedule.DAY_CHOICES
        ]


class Clinic(models.Model):
    name = models.CharField(max_length=200)
    location = models.CharField(max_length=200, blank=True)
    
    regular_physicians = models.ManyToManyField(
        'Physician',
        blank=True,
        related_name='assigned_clinics',
        limit_choices_to={'physician_type__in': ['regular', 'psa']},
        help_text= "NROC and PSA physicians permanently assigned to this clinic"
    )
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ['name']

    def __str__(self):
        return self.name


class ClinicSchedule(models.Model):
    """Recurring weekly clinic assignment for NROC/PSA physicians.

    One row = one half-day: e.g. Dr. X, Monday, AM, Clinic A. A full day at
    one clinic is simply two rows (AM + PM) pointing at the same clinic, so a
    physician can spend the morning at one clinic and the afternoon at another.
    A physician can hold at most one clinic per (day, session).
    """
    DAY_CHOICES = [
        (0, 'Monday'),
        (1, 'Tuesday'),
        (2, 'Wednesday'),
        (3, 'Thursday'),
        (4, 'Friday'),
    ]
    SESSION_CHOICES = [
        ('am', 'Morning'),
        ('pm', 'Afternoon'),
    ]

    physician = models.ForeignKey(
        Physician, on_delete=models.CASCADE, related_name='clinic_schedule',
        limit_choices_to={'physician_type__in': ['regular', 'psa']},
    )
    clinic = models.ForeignKey(
        Clinic, on_delete=models.CASCADE, related_name='weekly_schedule',
    )
    day_of_week = models.PositiveSmallIntegerField(
        choices=DAY_CHOICES,
        help_text="Weekday (matches Python date.weekday(): Monday=0)",
    )
    session = models.CharField(max_length=2, choices=SESSION_CHOICES)

    class Meta:
        ordering = ['physician', 'day_of_week', 'session']
        constraints = [
            models.UniqueConstraint(
                fields=['physician', 'day_of_week', 'session'],
                name='one_clinic_per_physician_half_day',
            ),
        ]

    def __str__(self):
        return (f"{self.physician} — {self.get_day_of_week_display()} "
                f"{self.get_session_display()} @ {self.clinic}")


class DayReassignment(models.Model):
    """One-day location override for an NROC or PSA physician.

    Overrides the weekly schedule (or legacy clinic affiliation) for a single
    date: e.g. Dr. X normally works Mondays at Clinic A, but on 2026-08-03
    they are reassigned to Clinic B. Can override the full day or just the
    morning/afternoon half.
    """
    SESSION_CHOICES = [
        ('full', 'Full day'),
        ('am', 'Morning'),
        ('pm', 'Afternoon'),
    ]

    physician = models.ForeignKey(
        Physician, on_delete=models.CASCADE, related_name='day_reassignments',
        limit_choices_to={'physician_type__in': ['regular', 'psa']},
    )
    clinic = models.ForeignKey(
        Clinic, on_delete=models.CASCADE, related_name='day_reassignments',
        help_text="Where the physician will work on this date",
    )
    date = models.DateField()
    session = models.CharField(max_length=4, choices=SESSION_CHOICES, default='full')
    note = models.CharField(max_length=200, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['date', 'physician']
        constraints = [
            models.UniqueConstraint(
                fields=['physician', 'date', 'session'],
                name='one_reassignment_per_physician_date_session',
            ),
        ]

    def clean(self):
        """A full-day override can't coexist with a half-day one (and vice versa)."""
        qs = DayReassignment.objects.filter(
            physician=self.physician, date=self.date).exclude(pk=self.pk)
        if self.session == 'full' and qs.exists():
            raise ValidationError(
                'This physician already has a reassignment on this date. '
                'Remove it before adding a full-day reassignment.')
        if self.session != 'full' and qs.filter(session='full').exists():
            raise ValidationError(
                'This physician already has a full-day reassignment on this '
                'date. Remove it before adding a half-day reassignment.')

    def __str__(self):
        return (f"{self.physician} → {self.clinic} on {self.date} "
                f"({self.get_session_display()})")


class TimeOffRequest(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('denied', 'Denied'),
        ('cancelled', 'Cancelled'),
        
    ]
    TYPE_CHOICES = [
        ('vacation', 'Vacation'),
        ('sick', 'Sick Leave'),
        ('conference', 'Conference / CME'),
        ('personal', 'Personal'),
        ('other', 'Other'),
    ]

    physician = models.ForeignKey(Physician, on_delete=models.CASCADE, related_name='time_off_requests')
    start_date = models.DateField()
    end_date = models.DateField()
    request_type = models.CharField(max_length=20, choices=TYPE_CHOICES, default='vacation')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-start_date']

    def __str__(self):
        return f"{self.physician} — {self.start_date} to {self.end_date}"

    def workdays(self):
        """Every business day in the request, as a list of dates.

        Handles requests that span a year boundary (holidays are computed for
        every year in the range) and honors extra workdays (e.g. the Sunday
        before Thanksgiving) so duration matches the coverage views exactly.
        """
        holidays = set()
        extra = set()
        for y in range(self.start_date.year, self.end_date.year + 1):
            holidays |= set(get_holidays(y))
            extra |= get_extra_workdays(y)
        days = []
        current = self.start_date
        while current <= self.end_date:
            if is_workday(current, holidays, extra):
                days.append(current)
            current += datetime.timedelta(days=1)
        return days

    @property
    def duration_days(self):
        return len(self.workdays())

class CoverageAssignment(models.Model):
    clinic = models.ForeignKey(Clinic, on_delete=models.CASCADE, related_name='coverage_assignments')
    hours = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True)
    covering_physician = models.ForeignKey(
        Physician, on_delete=models.CASCADE, related_name='coverage_assignments',
        null=True, blank=True,  
        limit_choices_to={'physician_type': 'locum'},
        help_text="Locum physician providing coverage"
    )
    covered_physician = models.ForeignKey(
        Physician, on_delete=models.CASCADE, related_name='covered_assignments',
        null=True, blank=True,
        limit_choices_to={'physician_type': 'regular'},
        help_text="NROC physician being covered (optional)"
    )
    date = models.DateField()

    no_coverage_needed = models.BooleanField(
        default=False,
        help_text="Mark this day as resolved without assigning a locum (e.g., half day, shift swapped)."
    )
    no_coverage_reason = models.CharField(
        max_length=255, blank=True,
        help_text="Required reason when 'no coverage needed' is set (e.g., 'half day', 'physician swapped shift')."
    )

    hourly_rate_override = models.DecimalField(
        max_digits=10, decimal_places=2, null=True, blank=True,
        help_text="Override the locum's standard hourly rate for this specific assignment"
    )

    daily_rate_override = models.DecimalField(
        max_digits=10, decimal_places=2, null=True, blank=True,
        help_text="Override the locum's standard daily rate for this specific assignment"
    )
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['date', 'clinic']
        # OLD: unique_together = ['clinic', 'covering_physician', 'date']
        # That breaks once covering_physician can be null (multiple "no coverage"
        # rows would collide). Replaced with conditional constraints:
        constraints = [
            models.UniqueConstraint(
                fields=['clinic', 'covering_physician', 'date'],
                condition=models.Q(covering_physician__isnull=False),
                name='unique_clinic_locum_date_when_assigned',
            ),
            # One "no coverage needed" marker per covered physician per day
            models.UniqueConstraint(
                fields=['covered_physician', 'date'],
                condition=models.Q(no_coverage_needed=True),
                name='unique_no_coverage_per_covered_physician_per_day',
            ),
        ]


    def __str__(self):
        return f"{self.clinic} — {self.covering_physician} on {self.date}"
    
    @property
    def is_no_coverage(self):
        return self.no_coverage_needed


    @property
    def effective_hourly_rate(self):
        """Hourly rate used for pay — per-assignment override beats physician default."""
        if self.no_coverage_needed or self.covering_physician is None:   # ← NEW guard
            return Decimal('0.00')
        if self.hourly_rate_override is not None:
            return self.hourly_rate_override
        return self.covering_physician.hourly_rate or Decimal('0.00')
    
    @property
    def effective_daily_rate(self):
        if self.no_coverage_needed or self.covering_physician is None:   # ← NEW guard
            return Decimal('0.00')
        if self.hourly_rate_override is not None or self.covering_physician.hourly_rate:
            hours = self.hours if self.hours is not None else Decimal('0.00')   # ← null-safe
            return (self.effective_hourly_rate * hours).quantize(Decimal('0.01'))
        if self.daily_rate_override is not None:
            return self.daily_rate_override
        return self.covering_physician.daily_rate or Decimal('0.00')
       

    @property
    def cost(self):
        return self.effective_daily_rate


class PhysicianAvailability(models.Model):
    physician = models.ForeignKey(
        Physician, on_delete=models.CASCADE, related_name='availability_slots',
        limit_choices_to={'physician_type': 'locum'}
    )
    date = models.DateField()
    is_available = models.BooleanField(default=True)
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ['date', 'physician']
        unique_together = ['physician', 'date']

    def __str__(self):
        status = "Available" if self.is_available else "Unavailable"
        return f"{self.physician} — {self.date} ({status})"


class CoverageRequest(models.Model):
    """Tracks requested coverage days for PSA physicians."""
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('denied', 'Denied'),
    ]
    physician = models.ForeignKey(
        Physician, on_delete=models.CASCADE, related_name='coverage_requests'
    )
    requested_date = models.DateField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-requested_date']
        unique_together = ['physician', 'requested_date']

    def __str__(self):
        return f"{self.physician} — {self.requested_date} ({self.status})"
class OnCallSchedule(models.Model):
    """Weekend on-call schedule entries for NROC and PSA physicians.

    Each row represents one full week Mon - SUn of on-call
    coverage for one physician in one group. The wee is uniquely
    identified by its monoday date (`weekend_start_date`).

    A physician can be on call for at most one weekend per (group, weekend)
    combination, but two physicians from different groups CAN cover the
    same weekend (one NROC + one PSA).
    """
    GROUP_CHOICES = [
        ('nroc', 'NROC'),
        ('psa', 'PSA'),
    ]

    group = models.CharField(
        max_length=10, choices=GROUP_CHOICES,
        help_text="Which physician group this on-call entry belongs to."
    )
    physician = models.ForeignKey(
        Physician, on_delete=models.CASCADE, related_name='on_call_entries',
        limit_choices_to={'physician_type__in': ['regular', 'psa']},
        help_text="Physician scheduled to be on call this week."
    )
    weekend_start_date = models.DateField(
        help_text="Monday that starts the on-call week (runs through Sunday)."
    )
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['weekend_start_date', 'group']
        constraints = [
            models.UniqueConstraint(
                fields=['group', 'weekend_start_date', 'physician'],
                name='unique_oncall_per_group_weekend_physician',
            ),
        ]

    def __str__(self):
        return (
            f"{self.get_group_display()} on-call — {self.physician} "
            f"week of {self.weekend_start_date:%b %d, %Y}"
        )

    @property
    def monday(self):
        return self.weekend_start_date

    @property
    def sunday(self):
        return self.weekend_start_date + datetime.timedelta(days=6)

    @property
    def weekend_label(self):
        mon = self.monday
        sun = self.sunday
        # Format the day-of-month manually so it works on Windows too
        # (Windows strftime has no portable "no zero-pad" code).
        mon_month = mon.strftime("%b")
        sun_month = sun.strftime("%b")
        if mon.month == sun.month:
            # "Jun 1–7, 2026"
            return f"{mon_month} {mon.day}–{sun.day}, {mon.year}"
        # "Jun 29 – Jul 5, 2026"
        return f"{mon_month} {mon.day} – {sun_month} {sun.day}, {mon.year}"

    def clean(self):
        """Validate physician/group match and that the date is a Monday."""
        from django.core.exceptions import ValidationError

        errors = {}

        if self.weekend_start_date is not None:
            # Python's weekday(): Monday=0 .. Saturday=5, Sunday=6
            if self.weekend_start_date.weekday() != 0:   # 0 = Monday
                errors['weekend_start_date'] = "On-call shifts must start on a Monday."

        if self.physician_id and self.group:
            if self.group == 'nroc' and not self.physician.is_regular:
                errors['physician'] = (
                    'NROC on-call entries must reference an NROC physician.'
                )
            elif self.group == 'psa' and not self.physician.is_psa:
                errors['physician'] = (
                    'PSA on-call entries must reference a PSA physician.'
                )

        if errors:
            raise ValidationError(errors)


class UserProfile(models.Model):
    """Extends Django User with role and scope.

    Scope determines which physicians' time off a non-admin user can see:
    - 'nroc' → NROC physicians only
    - 'psa'  → PSA physicians only
    - 'all'  → both (admins always behave as 'all' regardless of scope)
    """
    ROLE_CHOICES = [
        ('admin', 'Administrator'),
        ('physician_admin', 'Physician Administrator'),
        ('physician', 'Physician'),
        ('nursing', 'Clinical'),
    ]
    SCOPE_CHOICES = [
        ('nroc', 'NROC Physicians'),
        ('psa', 'PSA Physicians'),
        ('all', 'Both NROC and PSA'),
    ]
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='physician')
    scope = models.CharField(
        max_length=10, choices=SCOPE_CHOICES, default='nroc',
        help_text="Which physician group this login represents."
    )
    physician = models.OneToOneField(
        Physician, on_delete=models.SET_NULL, null=True, blank=True,
        help_text="Optional: link to a specific physician record (not required for shared logins)."
    )

    @property
    def is_admin(self):
        return self.role == 'admin' or self.user.is_superuser
    
    @property
    def is_physician_admin(self):
        return self.role == 'physician_admin'


    @property
    def is_physician(self):
        return self.role == 'physician'
    
    @property
    def is_nursing(self):
        """Nursing logins are restricted to the Clinics page only."""
        return self.role == 'nursing'
    
    @property
    def can_approve_time_off(self):
        """True for full admins and physician administrators."""
        return self.is_admin or self.is_physician_admin

    def __str__(self):
        return f"{self.user.username} ({self.get_role_display()})"
